Setup commands:
```
dotnet add package Microsoft.EntityFrameworkCore -v 8.0.2
dotnet add package Microsoft.EntityFrameworkCore.Sqlite -v 8.0.2
dotnet add package Microsoft.EntityFrameworkCore.Tools -v 8.0.2

dotnet add package Pomelo.EntityFrameworkCore.MySql --version 8.0.2
```s